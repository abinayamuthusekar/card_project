// script.js
$(document).ready(function () {
    const userContainer = $('#user-container');

    function fetchUsers() {
        $.get('/users', function (users) {
            userContainer.empty();

            users.forEach(user => {
                const card = `
                    <div class="user-card">
                        <img src="${user.userProfileImg || 'default-img.jpg'}" alt="User Profile">
                        <h3>${user.username}</h3>
                        <p>${user.userAddress}</p>
                        <p>${user.userPhone}</p>
                        <p>${user.userMail}</p>
                        <p>${user.dateUpdated}</p>
                    </div>
                `;

                userContainer.append(card);
            });
        });
    }

    fetchUsers();
});
